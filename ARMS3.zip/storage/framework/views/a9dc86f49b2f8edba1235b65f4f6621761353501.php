
<?php $__env->startSection('title'); ?>
    Klasifikasi Sub Unsur SPIP | Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Klasifikasi Sub Unsur SPIP</h3>
            </div>
            <div class="card-body p-0 mt-lg-2 mt-0">
                <?php if(session('status')): ?>
                <div class="alert text-white bg-success" role="alert">
                    <div class="iq-alert-text"><b>Info!</b> <?php echo e(session('status')); ?></div>
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <i class="ri-close-line"></i>
                    </button>
                </div>
                <?php endif; ?>
                <div class="form-group">
                    <div class="text-right">
                        <a href="<?php echo e(url('klasifikasisubunsurspip/create')); ?>" class="btn btn-primary add-list"><i class="las la-plus mr-3"></i>Tambah Klasifikasi Sub Unsur SPIP</a>
                    </div>
                </div>
                <div class="table-responsive rounded mb-3">
                    <table id="list-data" class="table mb-0 tbl-server-info">
                        <thead class="bg-white text-uppercase">
                            <tr class="ligth ligth-data">
                                <!-- <th>
                                    <div class="checkbox d-inline-block">
                                        <input type="checkbox" class="checkbox-input" id="checkbox1">
                                        <label for="checkbox1" class="mb-0"></label>
                                    </div>
                                </th> -->
                                <th>No</th>
                                <th>Klasifikasi Sub Unsur </th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="ligth-body">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="modal fade" id="show<?php echo e($item->id); ?>" tabindex="-1" role="dialog"  aria-hidden="true">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title">Klasifikasi Sub Unsur SPIP</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                            <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <form class="form-horizontal" action="<?php echo e(url('klasifikasisubunsurspip')); ?>" method="post">
                                                <?php echo csrf_field(); ?>
                                                <div class="form-group row">
                                                    <label class="control-label col-sm-3 align-self-center" for="">Klasifikasi Sub Unsur SPIP</label>
                                                    <div class="col-sm-9">
                                                        <input type="text" name="klasifikasi_sub_unsur_spip" class="form-control" value="<?php echo e($item->klasifikasi_sub_unsur_spip); ?>" id="" readonly required>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('phppiechart/assets/js/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/klasifikasisubunsurspip.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\arms\resources\views/backend/klasifikasi_sub_unsur_spip/index.blade.php ENDPATH**/ ?>