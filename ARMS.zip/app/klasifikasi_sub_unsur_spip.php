<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class klasifikasi_sub_unsur_spip extends Model
{
    protected $table = 'klasifikasi_sub_unsur_spip';
    protected $fillable = [
        'klasifikasi_sub_unsur_spip'
    ];
}
