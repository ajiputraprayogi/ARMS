<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class analisarisiko extends Model
{
    protected $table = 'analisa_risiko';
}
