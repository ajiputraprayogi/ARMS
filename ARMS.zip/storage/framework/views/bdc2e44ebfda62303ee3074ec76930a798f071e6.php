
<?php $__env->startSection('title'); ?>
    Pengendalian Risiko | Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>"> 
    <style>
        fieldset.scheduler-border {
            border: 1px groove #ddd !important;
            padding: 0 1.4em 1.4em 1.4em !important;
            margin: 0 0 1.5em 0 !important;
            -webkit-box-shadow: 0px 0px 0px 0px #000;
            box-shadow: 0px 0px 0px 0px #000;
        }

        legend.scheduler-border {
            width: inherit;
            /* Or auto */
            padding: 0 10px;
            /* To give a bit of padding on the left and right */
            border-bottom: none;
            font-size: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="col-md-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Pengendalian Risiko</h3>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <form class="form-horizontal" action="<?php echo e(url('pengendalian/'.$row->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="PUT">
                        <div class="form-group">
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Departemen Pemilik Risiko*</label>
                            <div class="col-sm-9">
                                <!-- Select2 -->
                                <select name="departemen" class="form" id="cari_departemen_manajemen" style="width: 100%;">
                                </select>
                                <input type="" value="<?php echo e($row->id_manajemen); ?>" name="id_manajemen" id="id_manajemen">
                                <input type="" value="<?php echo e($row->id_departemen); ?>" name="id_departemen" id="id_departemen">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Periode Penerapan*</label>
                            <div class="col-sm-9">
                                <input type="text" name="priode_penerapan" id="priode_penerapan" class="form-control" value="<?php echo e($row->priode_penerapan); ?>" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Risiko*</label>
                            <div class="col-sm-9">
                                <!-- Select2 -->
                                <select name="risiko" class="form" id="cari_risiko" style="width: 100%;">
                                </select>
                                <input type="hidden" value="<?php echo e($row->id_risiko); ?>" name="id_risiko" id="id_risiko">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Pernyataan Risiko*</label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="pernyataan_risiko" id="pernyataan_risiko" value="<?php echo e($row->pernyataan_risiko); ?>" readonly>
                                <!-- <label id="pernyataan_risiko" for=""></label> -->
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Analisis Akar Masalah*</label>
                            <div class="col-sm-9">
                                <!-- Auto Kode Generate -->
                                <input type="hidden" value="" name="faktur" id="faktur" class="form-group form-control" required readonly>
                                <!-- Select2 -->
                                <select name="departemen" class="form" id="cari_departemen" style="width: 100%;" data-placeholder="Search ...">
                                </select>
                                <!-- <input type="hidden" name="id_departemen" id="id_departemen"> -->
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Kode Tindak Pengendalian*</label>
                            <div class="col-sm-9">
                                <input type="" class="form-control" name="nama_koordinator_pengelola_risiko" readonly id="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Respons Risiko *</label>
                            <div class="col-sm-9">
                                <?php
                                    //data hobi dari tabel siswa 
                                    $newpic =', '.$row->respons_risiko;
                                    $datahobi=explode(', ',$newpic);
                                ?>
                                <label for="checkbox1"><input type="checkbox" class="checkbox-input" name="respons_risiko[]" value="Mengurangi Frekuensi" id="checkbox1" <?php if (in_array("Mengurangi Frekuensi", $datahobi)) echo "checked";?> > Mengurangi Frekuensi</label><br>
                                <label for="checkbox2"><input type="checkbox" class="checkbox-input" name="respons_risiko[]" value="Mengurangi Dampak" id="checkbox2" <?php if (in_array("Mengurangi Dampak", $datahobi)) echo "checked";?> > Mengurangi Dampak</label>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Akar Penyebab*</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="akar_penyebab" id="exampleFormControlTextarea1" rows="5"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Kegiatan Pengendalian*</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="kegiatan_pengendalian" id="exampleFormControlTextarea1" rows="5" required><?php echo e($row->kegiatan_pengendalian); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Klasifikasi Sub Unsur SPIP*</label>
                            <div class="col-sm-9">
                            <select class="form-control" name="klasifikasi_sub_unsur_spip" id="" required>
                                <option selected value="<?php echo e($row->id_klasifikasi_sub_unsur_spip); ?>"><?php echo e($row->klasifikasi_sub_unsur_spip); ?></option>
                                <?php $__currentLoopData = $klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->klasifikasi_sub_unsur_spip); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Penanggung Jawab*</label>
                            <div class="col-sm-9">
                                <input type="" class="form-control" name="penanggung_jawab" value="<?php echo e($row->penanggung_jawab); ?>" id="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Indikator Keluaran*</label>
                            <div class="col-sm-9">
                                <input type="" class="form-control" name="indikator_keluaran" value="<?php echo e($row->indikator_keluaran); ?>" id="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Target Waktu*</label>
                            <div class="col-sm-9">
                            <input type="date" class="form-control" id="dob" value="<?php echo e($row->target_waktu); ?>" name="target_waktu"/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Status Pelaksanaan*</label>
                            <div class="col-sm-9">
                            <select class="form-control" name="status_pelaksanaan" id="" required>
                                <option selected value="<?php echo e($row->status_pelaksanaan); ?>"><?php echo e($row->status_pelaksanaan); ?></option>
                                <option value="Dalam Proses Pelaksanaan">Dalam Proses Pelaksanaan</option>
                                <option value="Selesai Dilaksanakan">Selesai Dilaksanakan</option>
                                <option value="Belum Terealisasi">Belum Terealisasi</option>
                            </select>
                            </div>
                        </div>
                        <?php $__currentLoopData = $skorrisiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <fieldset class="scheduler-border">
                            <legend class="scheduler-border">Skor Risiko Yang direspons</legend>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Skor Frekuensi Saat Ini </label>
                                <input type="hidden" name="id_peta_besaran_risiko" value="<?php echo e($item->idb); ?>">
                                <div class="col-sm-9">
                                    <select class="form-control" name="skor_frekuensi_saat_ini" id="" disabled required>
                                            <option value="<?php echo e($item->idp); ?>"><?php echo e($item->nilaip); ?> - <?php echo e($item->namap); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Skor Dampak Saat Ini</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="skor_dampak_saat_ini" id="" disabled required>
                                            <option value="<?php echo e($item->idd); ?>"><?php echo e($item->nilaid); ?> - <?php echo e($item->namad); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Besaran risiko Saat Ini</label>
                                <div class="col-sm-1">
                                    <div style="border: 0; padding: 10px; background-color: <?php echo e($item->kode_warna); ?>; text-align: center;"><?php echo e($item->nilaib); ?></div>
                                    <input type="hidden" name="pr" value="<?php echo e($item->kode_warna); ?>">
                                    <input type="hidden" name="besaran_akhir" value="<?php echo e($item->nilaib); ?>">
                                </div>
                            </div>
                            <!-- <legend class="scheduler-border">Skor Risiko Yang direspons</legend>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Skor Frekuensi Saat Ini </label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="skor_frekuensi_saat_ini" id="" disabled required>
                                        <?php $__currentLoopData = $frekuensiterakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nilai); ?> - <?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Skor Dampak Saat Ini</label>
                                <div class="col-sm-9">
                                    <select class="form-control" name="skor_dampak_saat_ini" id="" disabled required>
                                        <?php $__currentLoopData = $dampakterakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nilai); ?> - <?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3" for="">Status Pelaksanaan*</label>
                                <div class="col-sm-1">
                                    <?php $__currentLoopData = $risikoterakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div style="border: 0; padding: 10px; background-color: <?php echo e($item->pr); ?>; text-align: center;"><?php echo e($item->besaran_akhir); ?></div>
                                        <input type="hidden" name="pr" value="<?php echo e($item->pr); ?>">
                                        <input type="hidden" name="besaran_akhir" value="<?php echo e($item->besaran_akhir); ?>">
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div> -->
                        </fieldset>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary btn-lg">Simpan</button>
                            <button type="reset" onclick="history.go(-1)" class="btn btn-danger  btn-lg">Batal</button>
                        </div>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/customjs/backend/konteks.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/konteks.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/pemangku_kepentingan.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/pengendalian_risiko.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

 
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS\resources\views/backend/pengendalian_risiko/edit_pengendalian_risiko.blade.php ENDPATH**/ ?>