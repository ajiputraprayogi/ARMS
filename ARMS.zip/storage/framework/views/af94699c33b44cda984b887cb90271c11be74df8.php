
<?php $__env->startSection('title'); ?>
    Departemen | Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="col-md-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Departemen</h3>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card-body">
                <form class="form-horizontal" action="<?php echo e(url('departemen')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="">Kode Departemen</label>
                        <div class="col-sm-9">
                            <input type="text" name="kode" class="form-control" id="" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="">Nama Departemen</label>
                        <div class="col-sm-9">
                            <input type="text" name="nama" class="form-control" id="" required>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="form-group">
                            <button class="btn btn-primary">Simpan</button>
                            <button type="reset" onclick="history.go(-1)" class="btn btn-danger">Batal</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('phppiechart/assets/js/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/konteks.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/pemangku_kepentingan.js')); ?>"></script>
<?php $__env->stopPush(); ?>

 
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel\arms\resources\views/backend/departemen/add_departemen.blade.php ENDPATH**/ ?>