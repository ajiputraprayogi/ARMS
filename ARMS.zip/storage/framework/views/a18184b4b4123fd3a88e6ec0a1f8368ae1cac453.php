
<?php $__env->startSection('title'); ?>
    Peta Besaran Risiko | Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="col-md-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Peta Besaran Risiko</h3>
            </div>
            <div class="card-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form class="form-horizontal" action="<?php echo e(url('petabesaranresiko/'.$dataku->id)); ?>" method="post">
                
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="PUT">
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Kriteria Probabilitas</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="probabilitas">
                                
                                <option selected value="<?php echo e($dataku->id_prob); ?>"><?php echo e($dataku->nilai_probabilitas); ?> - <?php echo e($dataku->nama_probabilitas); ?></option>
                                
                                <?php $__currentLoopData = $probabilitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data1->id); ?>"><?php echo e($data1->nilai); ?> - <?php echo e($data1->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Kriteria Dampak</label>
                        <div class="col-sm-9">
                            <select class="form-control" name="dampak">
                                
                                <option selected  value="<?php echo e($dataku->id_dampak); ?>"><?php echo e($dataku->nilai_damp); ?> - <?php echo e($dataku->nama_damp); ?></option>
                                
                                <?php $__currentLoopData = $dampak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($data2->id); ?>"><?php echo e($data2->nilai); ?> - <?php echo e($data2->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3" for="email">Nilai Besaran Risiko</label>
                        <div class="col-sm-9">
                            <input type="number" class="form-control col-sm-2" name="nilai" value="<?php echo e($dataku->nilai_besaran); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3" for="email">Kode Warna</label>
                        <div class="col-sm-9">
                            <input type="color" class="form-control col-sm-1" id="exampleInputcolor" value="<?php echo e($dataku->kode_warna); ?>" name="warna">
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button class="btn btn-danger">Batal</button>
                        </div>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('phppiechart/assets/js/highcharts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/konteks.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/pemangku_kepentingan.js')); ?>"></script>
<?php $__env->stopPush(); ?>

 
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS\resources\views/backend/peta_besaran_resiko/edit.blade.php ENDPATH**/ ?>