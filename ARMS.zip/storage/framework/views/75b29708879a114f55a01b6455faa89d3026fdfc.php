
<?php $__env->startSection('title'); ?>
Toko Online | Analisa Risiko
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
.bintang {
    color: red;
}

fieldset.scheduler-border {
    border: 1px groove #ddd !important;
    padding: 0 1.4em 1.4em 1.4em !important;
    margin: 0 0 1.5em 0 !important;
    -webkit-box-shadow: 0px 0px 0px 0px #000;
    box-shadow: 0px 0px 0px 0px #000;
}

legend.scheduler-border {
    width: inherit;
    /* Or auto */
    padding: 0 10px;
    /* To give a bit of padding on the left and right */
    border-bottom: none;
    font-size: 15px;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-transparent card-block card-stretch card-height border-none">
        <div class="card-header p-0 mt-lg-2 mt-0">
            <h3 class="mb-3">Edit Analisis Risiko</h3>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowdtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
            $data_manajemen_risiko = DB::table('pelaksanaan_manajemen_risiko')
            ->select(DB::raw('pelaksanaan_manajemen_risiko.*,departemen.nama'))
            ->leftjoin('departemen','departemen.id','=','pelaksanaan_manajemen_risiko.id_departemen')
            ->where('pelaksanaan_manajemen_risiko.id',$rowdtl->id_pelaksanaan_manajemen_risiko)
            ->get();

            $dataresikoselected = DB::table('resiko_teridentifikasi')
            ->where('full_kode',$rowdtl->kode_risiko)
            ->get();
            ?>
            <form class="form-horizontal" action="<?php echo e(url('analisa-risiko/'.$rowdtl->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="_method" value="put">
                <div class="form-group row">
                    <label class="control-label col-sm-3 align-self-center" for="email">Departemen Pemilik Reesiko<i
                            class="bintang">*</i></label>
                    <div class="col-sm-9">
                        <select class="js-example-basic-single text search-input" id="cari_departmen" name="departmen"
                            style="width:100%;">
                            <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dmr->id); ?>-<?php echo e($dmr->id_departemen); ?>"><?php echo e($dmr->nama); ?> -
                                (<?php echo e($dmr->priode_penerapan); ?>)</option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                
                <input type="hidden" name="id" id="id" <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dmr->id); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                <input type="hidden" name="id_dep" id="id_dep" <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dmr->id_departemen); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                <input type="hidden" name="kodedep" id="kodedep">
                <input type="hidden" name="namadep" id="namadep">
                
                <div class="form-group row">
                    <label class="control-label col-sm-3 align-self-center" for="email">Tahun<i
                            class="bintang">*</i></label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="tahun" name="tahun" <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dmr->priode_penerapan); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> readonly>
                        </select>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="control-label col-sm-3 align-self-center" for="email">Kode Risiko<i
                            class="bintang">*</i></label>
                    <div class="col-sm-9">
                        <select class="js-example-basic-single text search-input" id="cari_kode" name="kode"
                            style="width:100%;">
                            <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                            $dataresiko = DB::table('resiko_teridentifikasi')
                            ->where([['id_departmen',$dmr->id_departemen],['periode_penerapan',$dmr->priode_penerapan]])
                            ->get();
                            ?>
                            <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dtr->id); ?>" <?php if($dtr->full_kode==$rowdtl->kode_risiko): ?> selected
                                <?php endif; ?>><?php echo e($dtr->full_kode); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>

                    </div>
                </div>
                
                <input type="hidden" name="full_kode" id="full_kode" <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dtr->full_kode); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                <div class="form-group row">
                    <label class="control-label col-sm-3 align-self-center" for="email">Pernyataan Risiko</label>
                    <div class="col-sm-9">
                        <textarea class="form-control" id="pernyataan" name="pernyataan" readonly
                            row="3"><?php $__currentLoopData = $dataresikoselected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($dtr->pernyataan_risiko); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
                    </div>
                </div>
                <fieldset class="scheduler-border">
                    <legend class="scheduler-border">Skor yang melekat</legend>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Frekuensi Saat Ini<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="form-control" name="frekkini" id="cario" onchange="caribesaran()">
                                <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>" <?php if($row->id==$rowdtl->id_prob): ?> selected
                                    <?php endif; ?>><?php echo e($row->nilai); ?> - <?php echo e($row->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Dampak Saat Ini<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="form-control" name="dampakini" id="dampakk" onchange="caribesaran()"
                                class="dampakk">
                                <?php $__currentLoopData = $dampak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row2->id); ?>" <?php if($row2->id==$rowdtl->id_dampak): ?> selected
                                    <?php endif; ?>><?php echo e($row2->nilai); ?> - <?php echo e($row2->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Besaran Saat Ini<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <input type="text" name="besaran" value="<?php echo e($rowdtl->besaran_melekat); ?>"
                                style="background-color:<?php echo e($rowdtl->pr); ?>;" id="besaran" class="box1" readonly>
                        </div>
                    </div>
                    <?php
                    $proval = explode(' - ',$rowdtl->frekuensi_melekat);
                    $dampakval = explode(' - ',$rowdtl->dampak_melekat);
                    ?>
                    <input type="hidden" name="warna" id="warna" value="<?php echo e($rowdtl->pr); ?>">
                    <input type="hidden" name="nilpro" id="nilpro" value="<?php echo e($proval[0]); ?>">
                    <input type="hidden" name="nildam" id="nildam" value="<?php echo e($dampakval[0]); ?>">
                    <input type="hidden" name="nampro" id="nampro" value="<?php echo e($proval[1]); ?>">
                    <input type="hidden" name="namdam" id="namdam" value="<?php echo e($dampakval[1]); ?>">
                    <input type="hidden" name="idpro" id="idpro" value="<?php echo e($rowdtl->id_prob); ?>">
                    <input type="hidden" name="iddam" id="iddam" value="<?php echo e($rowdtl->id_dampak); ?>">
                </fieldset>
                <div class="form-group">
                    <b>Sudah Ada Pengendalian??</b><span> <input value="Sudah" name="sudah_ada_pengendalian"
                            id="sudah_ada_pengendalian" type="checkbox" <?php if($rowdtl->sudah_ada_pengendalian=='Sudah'): ?>
                        checked <?php endif; ?>></label></span>
                </div>
                <fieldset class="scheduler-border" id="input_pengendalian_div" <?php if($rowdtl->
                    sudah_ada_pengendalian!='Sudah'): ?> style="display:none;" <?php endif; ?>>
                    <legend class="scheduler-border">Pengendalian Yang Ada</legend>
                    <div class="form-group row">
                        <label class="control-label col-sm-3" for="email">Uraian Pengendalian</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" name="uraian_pengendalian" id="uraian_pengendalian" rows="4"
                                required><?php echo e($rowdtl->uraian_pengendalian); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3" for="email">Apakah Memadai</label>
                        <div class="col-sm-9">
                            <select name="apakah_memadai" class="form-control" id="apakah_memadai">
                                <option value="Memadai" <?php if($rowdtl->apakah_memadai=='Memadai'): ?> selected <?php endif; ?>>Memadai
                                </option>
                                <option value="Belum Memadai" <?php if($rowdtl->apakah_memadai=='Belum Memadai'): ?> selected
                                    <?php endif; ?>>Belum Memadai</option>
                            </select>
                        </div>
                    </div>
                </fieldset>
                <fieldset class="scheduler-border">
                    <legend class="scheduler-border">Skor Residu Setelah Pengendalian</legend>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Frekuensi Residu<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="form-control" name="frekkini" id="carir"
                                <?php if($rowdtl->sudah_ada_pengendalian!='Sudah'): ?> readonly <?php endif; ?>
                                onchange="cariresiduotomatis()">
                                <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row->id); ?>" <?php if($row->id==$rowdtl->id_prob_residu): ?> selected
                                    <?php endif; ?>><?php echo e($row->nilai); ?> - <?php echo e($row->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Dampak Residu<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="form-control" name="dampakini" id="dampakkr" onchange="cariresiduotomatis()"
                                <?php if($rowdtl->sudah_ada_pengendalian!='Sudah'): ?> readonly <?php endif; ?>>
                                <?php $__currentLoopData = $dampak; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row2->id); ?>" <?php if($row2->id==$rowdtl->id_dampak_residu): ?> selected
                                    <?php endif; ?>><?php echo e($row2->nilai); ?> - <?php echo e($row2->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Skor Besaran Residu<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <input type="text" name="besarankini" id="besarankini" value="<?php echo e($rowdtl->besaran_residu); ?>"
                                style="background-color:<?php echo e($rowdtl->pr_residu); ?>;" class="box1" readonly>
                        </div>
                        <?php
                        $proval_residu = explode(' - ',$rowdtl->frekuensi_residu);
                        $dampakval_residu = explode(' - ',$rowdtl->dampak_residu);
                        ?>
                        <input type="hidden" name="warnar" id="warnar" value="<?php echo e($rowdtl->pr_residu); ?>">
                        <input type="hidden" name="nilpror" id="nilpror" value="<?php echo e($proval_residu[0]); ?>">
                        <input type="hidden" name="nildamr" id="nildamr" value="<?php echo e($dampakval_residu[0]); ?>">
                        <input type="hidden" name="nampror" id="nampror" value="<?php echo e($proval_residu[1]); ?>">
                        <input type="hidden" name="namdamr" id="namdamr" value="<?php echo e($dampakval_residu[1]); ?>">
                        <input type="hidden" name="idpror" id="idpror" value="<?php echo e($rowdtl->id_prob_residu); ?>">
                        <input type="hidden" name="iddamr" id="iddamr" value="<?php echo e($rowdtl->id_dampak_residu); ?>">
                    </div>
                </fieldset>
                <div class="text-right">
                    <div class="form-group">
                        <button class="btn btn-primary">Simpan</button>
                        <button type="reset" onclick="history.go(-1)" class="btn btn-danger">Batal</button>
                    </div>
                </div>
            </form>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('assets/customjs/backend/analisa_risiko.js')); ?>"></script>


<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS\resources\views/backend/resiko/analisa/edit.blade.php ENDPATH**/ ?>