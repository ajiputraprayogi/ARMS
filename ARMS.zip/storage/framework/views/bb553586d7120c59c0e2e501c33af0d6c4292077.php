
<?php $__env->startSection('title'); ?>
Toko Online | Analisa Risiko
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
.bintang {
    color: red;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('assets/customjs/backend/loading.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-transparent card-block card-stretch card-height border-none">
        <div class="card-header p-0 mt-lg-2 mt-0">
            <h3 class="mb-3">Edit Analisis Akar Masalah</h3>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="loading-div" id="panel">
                <?php $__currentLoopData = $datadetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowdtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $dataresiko = DB::table('resiko_teridentifikasi')
                ->where('full_kode',$rowdtl->kode_risiko)
                ->get();
                ?>
                <form class="form-horizontal" action="<?php echo e(url('analisa-akar-masalah/'.$rowdtl->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="put">
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Departemen Pemilik Resiko<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="js-example-basic-single text search-input" id="cari_departmen"
                                name="cari_departmen" style="width:100%;">
                                <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $data_manajemen_risiko = DB::table('pelaksanaan_manajemen_risiko')
                                ->select(DB::raw('pelaksanaan_manajemen_risiko.*,departemen.nama'))
                                ->leftjoin('departemen','departemen.id','=','pelaksanaan_manajemen_risiko.id_departemen')
                                ->where([['id_departemen',$dtr->id_departmen],['priode_penerapan',$dtr->periode_penerapan]])
                                ->get();
                                ?>
                                <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dmr->id); ?>-<?php echo e($dmr->id_departemen); ?>"><?php echo e($dmr->nama); ?> -
                                    (<?php echo e($dmr->priode_penerapan); ?>)</option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" name="id" id="id">
                    <input type="hidden" name="id_dep" id="id_dep">
                    <input type="hidden" name="kodedep" id="kodedep">
                    <input type="hidden" name="namadep" id="namadep">
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Tahun<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="tahun" name="tahun" <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dtr->periode_penerapan); ?>" <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> readonly>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Risiko<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="js-example-basic-single text search-input" id="cari_risiko"
                                name="cari_risiko" style="width:100%;">
                                <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                $dataresiko = DB::table('resiko_teridentifikasi')
                                ->where([['id_departmen',$dmr->id_departemen],['periode_penerapan',$dmr->priode_penerapan]])
                                ->get();
                                ?>

                                <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($dtr->full_kode); ?>" <?php if($dtr->full_kode==$rowdtl->kode_risiko): ?> selected
                                    <?php endif; ?>><?php echo e($dtr->full_kode); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <input type="hidden" id="full_kode" name="full_kode">
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Pernyataan Risiko</label>
                        <div class="col-sm-9">
                            <textarea class="form-control" id="pernyataan" name="pernyataan" col="3"
                                readonly><?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($dtr->pernyataan_risiko); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Kode Analisis</label>
                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="kode_analisis" name="kode_analisis"
                                value="<?php echo e($rowdtl->kode_analisis); ?>" required readonly>
                        </div>
                    </div>
                    <div class="form-group">
                        <b>Why?</b>
                    </div>
                    <div class="form-group">
                        <div class="text-right">
                            <button type="button" class="btn btn-sm btn-primary add-list" data-toggle="modal"
                                data-target="#modaltambahwhy"><i class="las la-plus mr-3"></i>Tambah Why</button>
                        </div>
                    </div>
                    <div class="table-responsive rounded mb-3">
                        <table id="" class="table mb-0 tbl-server-info data-tables">
                            <thead class="bg-white text-uppercase">
                                <tr class="ligth ligth-data">
                                    <th>Urutan</th>
                                    <th>Uraian Why</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody class="ligth-body" id="bodywhy">
                            </tbody>
                        </table>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Akar Penyebab<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <textarea id="w3review" name="penyebab" rows="4" cols="50"
                                class="form-control"><?php echo e($rowdtl->akar_masalah); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Kode Penyebab<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <select class="form-control" name="kategori" onchange="generatekode()" id="carikat">
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->kode); ?>" <?php if($rowdtl->kategori_penyebab==$item->kode): ?> selected
                                    <?php endif; ?>><?php echo e($item->kode); ?> - <?php echo e($item->penyebab); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-3 align-self-center" for="email">Tindak Pengendalian<i
                                class="bintang">*</i></label>
                        <div class="col-sm-9">
                            <textarea id="w3review" name="pengendalian" rows="4" cols="50"
                                class="form-control"><?php echo e($rowdtl->tindakan_pengendalian); ?></textarea>
                        </div>
                    </div>
                    <div class="text-right">
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="reset" onclick="history.go(-1)" class="btn btn-danger">Batal</button>
                        </div>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<div class="modal fade" id="modaltambahwhy" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Tambah Why</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="formaddwhy" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Akar Penyebab</label>
                        <textarea name="akar_penyebab" id="akar_penyebab" class="form-control" rows="6"></textarea>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" id="addakarpenyebab" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<div class="modal fade" id="modaleditwhy" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="labelmodal"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" id="formeditwhy" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label>Akar Penyebab</label>
                        <input type="hidden" name="kode_why" id="kode_why" required readonly>
                        <textarea name="edit_akar_penyebab" id="edit_akar_penyebab" class="form-control"
                            rows="6"></textarea>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" id="editakarpenyebab" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<!-- <script src="<?php echo e(asset('phppiechart/assets/js/highcharts.js')); ?>"></script> -->
<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="<?php echo e(asset('assets/customjs/backend/loading.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customjs/backend/analisa_akar.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS\resources\views/backend/resiko/akar_masalah/edit.blade.php ENDPATH**/ ?>