@extends('layouts.base')
@section('title')
Daftar Pelaksanaan Manajemen Risiko | Dashboard
@endsection
@section('token')
<meta name="csrf-token" content="{{ csrf_token() }}">
@endsection
@section('content')
<div class="col-lg-12">
    <div>
        <h4 class="mb-3">Data Pelaksanaan Manajemen Risiko</h4>
        <form method="get">
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <select class="form-control" name="departemen" id="">
                            <option>Semua Departemen</option>
                            @foreach($departemen as $rowdpr)
                            <option value="{{$rowdpr->id}}" @if($active_departemen==$rowdpr->id) selected
                                @endif>{{$rowdpr->nama}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="input-group mb-3">
                        <select class="form-control" name="tahun" id="">
                            <option>Semua Tahun</option>
                            @foreach($tahun as $rowthn)
                            <option value="{{$rowthn->priode_penerapan}}" @if($active_tahun==$rowthn->priode_penerapan)
                                selected @endif>{{$rowthn->priode_penerapan}}</option>
                            @endforeach
                        </select>
                        <div class="input-group-prepend" style="border-radius:10p;">
                            <button type="submit" class="btn btn-secondary"><i class="fas fa-search"></i></button>
                            <a href="{{url('/pelaksanaan')}}" class="btn btn-secondary"
                                style="border-top-right-radius: 10px;border-bottom-right-radius: 10px;"><i
                                    class="fas fa-sync"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 text-right">
                    <a href="{{url('pelaksanaan/create')}}" class="btn btn-primary mb-3 btn-lg"><i
                            class="las la-plus mr-3"></i>Tambah Pelaksanaan Baru</a>
                </div>
            </div>
        </form>
    </div>
</div>
<div class="col-lg-12 mt-2">
    <div class="card card-transparent card-block card-stretch card-height border-none">
        <div class="card-body p-0 mt-lg-2 mt-0">
            <div class="table-responsive rounded mb-3">
                <table class="table">
                    <thead class="bg-white text-uppercase">
                        <tr class="ligth ligth-data">
                            <th>No</th>
                            <th>Departemen</th>
                            <th>Tahun</th>
                            <th>Jumlah Konteks</th>
                            <th>Jumlah Risiko</th>
                            <th>Selera Risiko</th>
                            <th>PIC</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    @php $i=($data->currentpage()-1)* $data->perpage(); @endphp
                    @foreach($data as $row)
                    @php $i++ @endphp
                    <tbody class="ligth-body">
                        <th>{{$i}}</th>
                        <th>{{$row->nama}}</th>
                        <th class="text-center">{{$row->priode_penerapan}}</th>
                        <th class="text-center">{{$row->totalkonteks}}</th>
                        <th class="text-center">{{$row->totalrisiko}}</th>
                        <th class="text-center">{{$row->selera_risiko}}</th>
                        <th>{{$row->nama_pemilik_risiko}}</th>
                        <th class="text-center">
                            <a class="badge badge-info mr-2" data-toggle="modal" data-target="#showpemangku{{$row->id}}"
                                title="View" data-original-title="View"><i class="ri-eye-line mr-0"></i></a>
                            <a class="badge bg-success mr-2" href="{{url('edit-pelaksanaan/'.$row->faktur)}}"
                                title="View" data-original-title="View"><i class="ri-pencil-line mr-0"></i></a>
                            <a class="badge bg-warning mr-2" data-toggle="tooltip" data-placement="top" title=""
                                data-original-title="Delete" onclick="hapusdatamanajemenrisiko({{$row->id}})"><i
                                    class="ri-delete-bin-line mr-0"></i><input type="hidden" name="faktur"
                                    value="{{$row->faktur}}"></a>
                            <!-- <a class="badge bg-warning mr-2" data-original-title="Delete" href="{{''}}"><i class="ri-delete-bin-line mr-0"></i></a> -->
                        </th>
                    </tbody>
                    @endforeach
                </table>
                {{ $data->appends($_GET)->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
@push('script')
<script src="{{asset('assets/customjs/backend/manajemen_risiko.js')}}"></script>
@endpush