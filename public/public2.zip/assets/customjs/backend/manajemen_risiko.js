btnPelaksanaan=function(){
    document.getElementById("formPelaksanaan").action = "/pelaksanaan";
         document.forms["formPelaksanaan"].submit();
    }