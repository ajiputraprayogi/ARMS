
<?php $__env->startSection('title'); ?>
    Daftar Rencana Tindak Pengendalian | ARMS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="col-lg-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Daftar Rencana Tindak Pengendalian</h3>
                <form method="get">
                <div class="row">
                    <div class="col-md-3">
                        <label for="">Departemen</label>
                        <div class="form-group">
                        <select class="form-control" name="departemen" id="">
                            <option>Semua Departemen</option>
                            <?php $__currentLoopData = $departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowdpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rowdpr->id); ?>" <?php if($active_departemen==$rowdpr->id): ?> selected
                                <?php endif; ?>><?php echo e($rowdpr->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Kode Risiko</label>
                        <div class="form-group">
                        <select class="form-control" name="kode_risiko" required>
                            <option value="Belum Dilaksanakan">Semua Kode Risiko</option>
                            <!-- <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rowsts->status_pelaksanaan); ?>" <?php if($active_status==$rowsts->status_pelaksanaan): ?> selected
                                <?php endif; ?>><?php echo e($rowsts->status_pelaksanaan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                        </select>
                      
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Status</label>
                        <div class="form-group">
                        <select class="form-control" name="status" required>
                            <option>Semua Status</option>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rowsts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($rowsts->status_pelaksanaan); ?>" <?php if($active_status==$rowsts->status_pelaksanaan): ?> selected
                                <?php endif; ?>><?php echo e($rowsts->status_pelaksanaan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                      
                        </div>
                    </div>
                    <div class="col-md-3">
                        <label for="">Target Waktu Awal</label>
                        <div class="input-group mb-3">
                                <input class="form-control" id="tanggal"
                                        name="target_waktu" placeholder="Pilih Target Waktu Awal" value="<?php echo e($get_target_waktu); ?>" />
                        </div>
                    </div>
                    <div class="col-md-4">
                        <label for="">Target Waktu Akhir</label>
                        <div class="input-group mb-3">
                                <input class="form-control" id="tanggal"
                                        name="target_waktu_akhir" placeholder="Pilih Target Waktu Akhir" value="<?php echo e($get_target_waktu_akhir); ?>" />
                            <div class="input-group-prepend" style="border-radius:10p;">
                                <button type="submit" class="btn btn-secondary"><i class="fas fa-search"></i></button>
                                <a href="<?php echo e(url('/pengendalian')); ?>" class="btn btn-secondary"
                                    style="border-top-right-radius: 10px;border-bottom-right-radius: 10px;"><i
                                        class="fas fa-sync"></i></a>
                            </div>
                    </div>
                </div>
                    <!-- <div class="col-md-9">
                        <label for="">Tahun</label>
                        <div class="row">
                            <div class="col-md-3">
                                <div class="form-group">
                                    <input type="date" class="form-control" id="dob" name="tanggal1"/>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="">
                                    <button type="submit" class="btn btn-primary">Reset Filter</button>
                                </div>
                            </div>
                        </div>
                    </div> -->
                </div>
            </form>
            </div>
            <hr>
            <div class="card-body p-0 mt-lg-2 mt-0">
                <div class="form-group">
                    <div class="text-right">
                        <a href="<?php echo e(url('pengendalian/create')); ?>" class="btn btn-primary add-list"><i class="las la-plus mr-3"></i>Tambah Tindakan Pengendalian</a>
                    </div>
                </div>
                <div class="table-responsive rounded mb-3">
                    <table id="" class="table mb-0 tbl-server-info data-tables">
                        <thead class="bg-white text-uppercase">
                            <tr class="ligth ligth-data">
                                <!-- <th>
                                    <div class="checkbox d-inline-block">
                                        <input type="checkbox" class="checkbox-input" id="checkbox1">
                                        <label for="checkbox1" class="mb-0"></label>
                                    </div>
                                </th> -->
                                <th>Kode Pengendalian</th>
                                <th>Kode Risiko</th>
                                <th>Respons Risiko</th>
                                <th>Kegiatan Pengendalian</th>
                                <th>Penanggung Jawab</th>
                                <th>Target Waktu Mulai</th>
                                <th>Target Waktu Selesai</th>
                                <th>Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody class="ligth-body">
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($item->kode_tindak_pengendalian); ?></td>
                                <td><?php echo e($item->full_kode); ?></td>
                                <td><?php echo e($item->respons_risiko); ?></td>
                                <td><?php echo e($item->kegiatan_pengendalian); ?></td>
                                <td><?php echo e($item->penanggung_jawab); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($item->target_waktu))); ?></td>
                                <td><?php echo e(date('d-m-Y', strtotime($item->target_waktu_akhir))); ?></td>
                                <td><?php echo e($item->status_pelaksanaan); ?></td>
                                <td>
                                <a class="btn btn-success btn-sm m-1"
                                        href="<?php echo e(url('/pengendalian/'.$item->id.'/edit')); ?>">
                                        <i class="ri-pencil-line mr-0"></i>
                                    </a>
                                    <button class="btn btn-sm btn-danger m-1" data-toggle="tooltip" data-placement="top"
                                        title="" data-original-title="Delete"
                                        onclick="hapusdatamanajemenrisiko(<?php echo e($item->id); ?>)"><i
                                            class="ri-delete-bin-line mr-0"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('phppiechart/assets/js/highcharts.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('assets/customjs/backend/manajemen_risiko.js')); ?>"></script> -->
    <script>
        function hapusdatamanajemenrisiko(kode) {
            const swalWithBootstrapButtons = Swal.mixin({
                customClass: {
                    confirmButton: 'btn btn-success',
                    cancelButton: 'btn btn-danger',
                },
                buttonsStyling: true
            })
            swalWithBootstrapButtons.fire({
                title: 'Hapus Data ?',
                text: "Data tidak dapat dipulihkan kembali!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Ya, Hapus!',
                cancelButtonText: 'Tidak',
                reverseButtons: true
            }).then((result) => {
                if (result.value) {
                    $.ajaxSetup({
                        headers: {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                        }
                    })
                    $.ajax({
                        type: 'DELETE',
                        url: '/pengendalian/' + kode,
                        data: {
                            'token': $('input[name=_token]').val(),
                        },
                        success: function() {
                            swalWithBootstrapButtons.fire(
                                'Deleted!',
                                'Data Berhasil Dihapus.',
                                'success'
                            )
                            location.reload();
                        }
                    })
                }
            })
        }
    </script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        $(function() {
        flatpickr("#tanggal", {
            enableTime: false,
            dateFormat: "d-m-Y",
            mode: "range",
        });
        });
    </script>
    <script>
        $(function() {
            $(".select").select2();
        });
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS2\resources\views/backend/pengendalian_risiko/pengendalian_risiko.blade.php ENDPATH**/ ?>