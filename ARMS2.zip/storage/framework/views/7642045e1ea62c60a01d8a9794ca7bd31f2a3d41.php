
<?php $__env->startSection('title'); ?>
Edit Rencana Tindak Pengendalian | ARMS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/customjs/backend/loading.css')); ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<style>
fieldset.scheduler-border {
    border: 1px groove #ddd !important;
    padding: 0 1.4em 1.4em 1.4em !important;
    margin: 0 0 1.5em 0 !important;
    -webkit-box-shadow: 0px 0px 0px 0px #000;
    box-shadow: 0px 0px 0px 0px #000;
}

legend.scheduler-border {
    width: inherit;
    padding: 0 10px;
    border-bottom: none;
    font-size: 15px;
}
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-md-12">
    <div class="card card-transparent card-block card-stretch card-height border-none">
        <div class="card-header p-0 mt-lg-2 mt-0">
            <h3 class="mb-3">Edit Rencana Tinadk Pengendalian</h3>
        </div>
        <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
        <?php endif; ?>
        <div class="card-body">
            <div class="loading-div" id="panel">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $data_manajemen_risiko = DB::table('pelaksanaan_manajemen_risiko')
                ->select(DB::raw('pelaksanaan_manajemen_risiko.*,departemen.nama'))
                ->leftjoin('departemen','departemen.id','=','pelaksanaan_manajemen_risiko.id_departemen')
                ->where('pelaksanaan_manajemen_risiko.id',$row->id_manajemen)
                ->get();

                $dataresiko = DB::table('resiko_teridentifikasi')
                ->where('id',$row->id_risiko)
                ->get();

                $dataakarselect = DB::table('analisa_masalah')
                ->where('id',$row->id_akar_masalah)
                ->get();
                ?>
                <form class="form-horizontal" action="<?php echo e(url('/pengendalian/'.$row->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="put">
                    <div class="form-group">
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Departemen Pemilik
                                Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <select name="departemen" class="form" id="cari_departemen_manajemen"
                                    style="width: 100%;">
                                    <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dmr->id); ?>-<?php echo e($dmr->id_departemen); ?>"><?php echo e($dmr->nama); ?> -
                                        (<?php echo e($dmr->priode_penerapan); ?>)</option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" value="<?php echo e($row->id_departemen); ?>" name="id_manajemen"
                                    id="id_manajemen">
                                <input type="hidden" value="<?php echo e($row->id_manajemen); ?>" name="id_departemen"
                                    id="id_departemen">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Periode Penerapan<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" name="priode_penerapan" id="priode_penerapan" class="form-control"
                                    <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> value="<?php echo e($dmr->priode_penerapan); ?>"
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <select name="risiko" class="form" id="cari_risiko" style="width: 100%;">
                                    <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $dataresikoo = DB::table('resiko_teridentifikasi')
                                    ->where([['id_departmen',$dmr->id_departemen],['periode_penerapan',$dmr->priode_penerapan]])
                                    ->get();
                                    ?>
                                    <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dtrs->id); ?>" <?php if($dtrs->
                                        id==$row->id_risiko): ?> selected
                                        <?php endif; ?>><?php echo e($dtrs->full_kode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="id_risiko" value="<?php echo e($row->id_risiko); ?>" id="id_risiko">
                                <input type="hidden" name="id_konteks" id="id_konteks">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Pernyataan Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <textarea class="form-control" id="pernyataan" name="pernyataan" col="3"
                                    readonly><?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($dtr->pernyataan_risiko); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Analisis Akar
                                Masalah<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <select name="departemen" class="form" id="cari_akar_masalah" style="width: 100%;">
                                    <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $dataakar = DB::table('analisa_masalah')
                                    ->where('kode_risiko',$dtrs->full_kode)
                                    ->get();
                                    ?>
                                    <?php $__currentLoopData = $dataakar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtakr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dtakr->id); ?>" <?php if($dtakr->
                                        id==$row->id_akar_masalah): ?> selected
                                        <?php endif; ?>><?php echo e($dtakr->kode_analisis); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="id_akar_masalah" value="<?php echo e($row->id_akar_masalah); ?>" id="id_akar_masalah" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Kode Tindak
                                Pengendalian<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" value="<?php echo e($row->kode_tindak_pengendalian); ?>"
                                    name="kode_tindak_pengendalian" id="kode_analisis" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Respons Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <?php
                                $newpic =', '.$row->respons_risiko;
                                $datarespon=explode(', ',$newpic);
                                ?>
                                <label for="checkbox1"><input type="checkbox" class="checkbox-input"
                                        name="respons_risiko[]" <?php $__currentLoopData = $datarespon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($dres=='Mengurangi Frekuensi'): ?> checked <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="Mengurangi Frekuensi" id="checkbox1"> Mengurangi
                                    Frekuensi</label><br>
                                <label for="checkbox2"><input type="checkbox" class="checkbox-input"
                                        name="respons_risiko[]" <?php $__currentLoopData = $datarespon; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dres): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php if($dres=='Mengurangi Dampak'): ?> checked <?php endif; ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> value="Mengurangi Dampak" id="checkbox2"> Mengurangi
                                    Dampak</label>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Detail Respons Risiko</label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="detail_respons_risiko"
                                    id="detail_respons_risiko" rows="5" required><?php echo e($row->detail_respons_risiko); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Akar Penyebab<i class="bintang">*</i></label>
                            <div class="col-sm-9">

                                <textarea class="form-control" name="akar_penyebab" id="akar_penyebab" rows="5"
                                    readonly><?php $__currentLoopData = $dataakarselect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtaks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($dtaks->akar_masalah); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></textarea>

                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Kegiatan Pengendalian<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="kegiatan_pengendalian" id="kegiatan_pengendalian"
                                    rows="5" required><?php echo e($row->kegiatan_pengendalian); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Klasifikasi Sub Unsur SPIP<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <select class="form-control" name="klasifikasi_sub_unsur_spip" id="" required>
                                    <?php $__currentLoopData = $klasifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php if($row->id_klasifikasi_sub_unsur_spip==$item->id): ?>
                                        selected <?php endif; ?>><?php echo e($item->klasifikasi_sub_unsur_spip); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Penanggung Jawab<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="penanggung_jawab"
                                    value="<?php echo e($row->penanggung_jawab); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Indikator Keluaran<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="indikator_keluaran"
                                    value="<?php echo e($row->indikator_keluaran); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Target Waktu<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input class="form-control" id="tanggal" value="<?php echo e(date('d-m-Y', strtotime($row->target_waktu))); ?> to <?php echo e(date('d-m-Y', strtotime($row->target_waktu_akhir))); ?>"
                                    name="target_waktu" />
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Status Pelaksanaan*</label>
                            <div class="col-sm-9">
                                <select class="form-control" name="status_pelaksanaan" required>
                                    <option value="Belum Dilaksanakan" <?php if($row->status_pelaksanaan=='Belum
                                        Dilaksanakan'): ?> selected <?php endif; ?>>Belum Dilaksanakan</option>
                                    <option value="Dalam Proses Pelaksanaan" <?php if($row->status_pelaksanaan=='Dalam Proses
                                        Pelaksanaan'): ?> selected <?php endif; ?>>Dalam Proses Pelaksanaan</option>
                                    <option value="Selesai Dilaksanakan" <?php if($row->status_pelaksanaan=='Selesai
                                        Dilaksanakan'): ?> selected <?php endif; ?>>Selesai Dilaksanakan</option>
                                    <option value="Belum Terealisasi" <?php if($row->status_pelaksanaan=='Belum Terealisasi'): ?>
                                        selected <?php endif; ?>>Belum Terealisasi</option>
                                    <option value="Terlambat" <?php if($row->status_pelaksanaan=='Terlambat'): ?>
                                        selected <?php endif; ?>>Terlambat</option>
                                </select>
                            </div>
                        </div>
                        <?php $__currentLoopData = $skorrisiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <input type="hidden" name="id_peta_besaran_risiko" value="<?php echo e($item->idb); ?>">
                        <fieldset class="scheduler-border">
                            <legend class="scheduler-border">Skor yang melekat</legend>
                            <div class="form-group row">
                                <label class="control-label col-sm-3 align-self-center" for="email">Skor Frekuensi Saat
                                    Ini<i class="bintang">*</i></label>
                                <div class="col-sm-9">
                                    <select class="form-control" disabled>
                                        <option value="<?php echo e($item->idp); ?>"><?php echo e($item->nilaip); ?> - <?php echo e($item->namap); ?></option>
                                    </select>
                                    <input type="hidden" name="frekuensi_saat_ini" id="frekuensi_saat_ini">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3 align-self-center" for="email">Skor Dampak Saat
                                    Ini<i class="bintang">*</i></label>
                                <div class="col-sm-9">
                                    <select class="form-control" disabled name="dampak_saat_ini" id="dampakk">\
                                        <option value="<?php echo e($item->idd); ?>"><?php echo e($item->nilaid); ?> - <?php echo e($item->namad); ?></option>>
                                    </select>
                                    <input type="hidden" name="dampak_saat_ini" id="dampak_saat_ini">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="control-label col-sm-3 align-self-center" for="email">Skor Besaran Saat
                                    Ini<i class="bintang">*</i></label>
                                <div class="col-sm-9">

                                    <input type="text" style="background-color: <?php echo e($item->kode_warna); ?>;"
                                        name="besaran_saat_ini" id="besaran" value="<?php echo e($item->nilaib); ?>" class="box1"
                                        readonly>
                                    <input type="hidden" name="pr_saat_ini" id="pr_saat_ini">
                                </div>
                            </div>
                        </fieldset>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="text-right">
                            <button type="submit" class="btn btn-primary btn-lg">Simpan</button>
                            <button type="reset" onclick="history.go(-1)" class="btn btn-danger  btn-lg">Batal</button>
                        </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customjs/backend/loading.js')); ?>"></script>
<script src="<?php echo e(asset('assets/customjs/backend/pengendalian_risiko_input.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    $(function() {
    flatpickr("#tanggal", {
        enableTime: false,
        dateFormat: "d-m-Y",
        mode: "range"
    });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS2\resources\views/backend/pengendalian_risiko/edit_pengendalian_risiko.blade.php ENDPATH**/ ?>