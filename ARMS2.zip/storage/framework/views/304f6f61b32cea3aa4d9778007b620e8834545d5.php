
<?php $__env->startSection('title'); ?>
    Edit Catatan Peristiwa Risiko | ARMS
<?php $__env->stopSection(); ?>
<?php $__env->startSection('token'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/customjs/backend/loading.css')); ?>">
    <style>
        fieldset.scheduler-border {
            border: 1px groove #ddd !important;
            padding: 0 1.4em 1.4em 1.4em !important;
            margin: 0 0 1.5em 0 !important;
            -webkit-box-shadow: 0px 0px 0px 0px #000;
            box-shadow: 0px 0px 0px 0px #000;
        }

        legend.scheduler-border {
            width: inherit;
            /* Or auto */
            padding: 0 10px;
            /* To give a bit of padding on the left and right */
            border-bottom: none;
            font-size: 15px;
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
   <div class="col-md-12">
        <div class="card card-transparent card-block card-stretch card-height border-none">
            <div class="card-header p-0 mt-lg-2 mt-0">
                <h3 class="mb-3">Edit Catatan Peristiwa Risiko</h3>
            </div>
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>
            <div class="card-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $data_manajemen_risiko = DB::table('pelaksanaan_manajemen_risiko')
                ->select(DB::raw('pelaksanaan_manajemen_risiko.*,departemen.nama'))
                ->leftjoin('departemen','departemen.id','=','pelaksanaan_manajemen_risiko.id_departemen')
                ->where('pelaksanaan_manajemen_risiko.id',$item1->id_manajemen)
                ->get();

                $dataresiko = DB::table('resiko_teridentifikasi')
                ->where('id',$item1->id_risiko)
                ->get();

                ?>
                    <form class="form-horizontal" action="<?php echo e(url('/pencatatan-peristiwa/'.$item1->id)); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="PUT">
                        <div class="form-group">
                            <div class="form-group row">
                                <label class="control-label col-sm-3 align-self-center" for="">Departemen Pemilik
                                    Risiko<i class="bintang">*</i></label>
                                <div class="col-sm-9">
                                    <select name="departemen" class="form" id="cari_departemen_manajemen"
                                        style="width: 100%;">
                                        <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($dmr->id); ?>-<?php echo e($dmr->id_departemen); ?>"><?php echo e($dmr->nama); ?> -
                                            (<?php echo e($dmr->priode_penerapan); ?>)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="hidden" value="<?php echo e($item1->id_departemen); ?>" name="id_manajemen"
                                        id="id_manajemen">
                                    <input type="hidden" value="<?php echo e($item1->id_manajemen); ?>" name="id_departemen"
                                        id="id_departemen">
                                </div>
                            </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Tahun<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" name="tahun" value="<?php echo e($item1->tahun); ?>" id="priode_penerapan" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <select name="risiko" class="form" id="cari_risiko" style="width: 100%;">
                                    <?php $__currentLoopData = $data_manajemen_risiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dmr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    $dataresikoo = DB::table('resiko_teridentifikasi')
                                    ->where([['id_departmen',$dmr->id_departemen],['periode_penerapan',$dmr->priode_penerapan]])
                                    ->get();
                                    ?>
                                    <?php $__currentLoopData = $dataresiko; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($dtrs->id); ?>" <?php if($dtrs->
                                        id==$item1->id_risiko): ?> selected
                                        <?php endif; ?>><?php echo e($dtrs->full_kode); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <input type="hidden" name="kode_risiko" id="kode_risiko" value="<?php echo e($item1->resiko_id); ?>">
                                <input type="hidden" name="id_risiko" value="<?php echo e($item1->id_risiko); ?>" id="id_risiko">
                                <input type="hidden" name="id_konteks" id="id_konteks">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Pernyataan Risiko<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="pernyataan_risiko" value="<?php echo e($item1->pernyataan); ?>" id="pernyataan_risiko" readonly>
                                <!-- <label id="pernyataan_risiko" for=""></label> -->
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Uraian Peristiwa<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="uraian" id="uraian" rows="5"><?php echo e($item1->uraianpencatatan); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Waktu Kejadian<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                            <input type="date" class="form-control" name="waktu" value="<?php echo e($item1->waktu); ?>"/>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3 align-self-center" for="">Tempat Kejadian<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <input type="text" class="form-control" name="tempat" id="tempat" value="<?php echo e($item1->tempat); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Skor Dampak<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                            <select class="form-control" name="skor" id="" required>
                                <option selected disabled value="">Pilih Skor Dampak</option>
                                <?php $__currentLoopData = $dampakterakhir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $item1->kriteria_id ? 'selected' : ''); ?>><?php echo e($item->nilai); ?> || <?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Pemicu Peristiwa<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                                <textarea class="form-control" name="pemicu" id="exampleFormControlTextarea1" rows="5" required><?php echo e($item1->pemicu); ?></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="control-label col-sm-3" for="">Kode Penyebab<i class="bintang">*</i></label>
                            <div class="col-sm-9">
                            <select class="form-control" name="kode_penyebab" id="" required>
                                <option selected disabled value="">Pilih Skor Dampak</option>
                                <?php $__currentLoopData = $penyebab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $item1->penyebab_id ? 'selected' : ''); ?>><?php echo e($item->kode); ?> || <?php echo e($item->penyebab); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            </div>
                        </div>

                        <div class="text-right">
                            <button type="submit" class="btn btn-primary btn-lg">Simpan</button>
                            <button type="reset" onclick="history.go(-1)" class="btn btn-danger  btn-lg">Batal</button>
                        </div>
                    </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
   </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/backend/loading.js')); ?>"></script>
    <!-- <script src="<?php echo e(asset('assets/customjs/backend/pencatatanperistiwa.js')); ?>"></script> -->
    <script src="<?php echo e(asset('assets/customjs/backend/pencatatanperistiwa_input.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/select2/js/select2.full.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS2\resources\views/backend/pencatatanperistiwa/update.blade.php ENDPATH**/ ?>