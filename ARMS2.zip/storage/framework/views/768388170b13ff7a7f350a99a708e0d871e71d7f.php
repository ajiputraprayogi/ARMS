
<?php $__env->startSection('title'); ?>
ARMS | Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <div class="card card-transparent card-block card-stretch card-height border-none">
        <div class="card-header p-0 mt-lg-2 mt-0">
            <h3 class="mb-3">Dashboard Pengawasan</h3>
            <form method="get">
                <div class="row">
                    <div class="col-md-4">
                        <label class="m-0">Departemen</label>
                        <div class="input-group mb-3">
                            <select class="form-control" name="departemen" id="departemen">
                                <option value="semua">Semua Departemen</option>
                                <?php $__currentLoopData = $data_departemen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_departemen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($row_departemen->id); ?>" <?php if(request()->get('departemen')): ?> <?php if(request()->get('departemen')==$row_departemen->id): ?> selected <?php endif; ?> <?php endif; ?>><?php echo e($row_departemen->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <div class="input-group-prepend" style="border-radius:10p;">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-search"></i></button>
                                <a href="<?php echo e(url('/dashboard')); ?>" class="btn btn-primary"
                                    style="border-top-right-radius: 10px;border-bottom-right-radius: 10px;"><i
                                        class="fas fa-sync"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <hr>
        <div class="card-body p-0 mt-lg-2 mt-0">
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Risiko</h4>
                            <div class="row">
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($populasi_risiko); ?></h3>
                                    <p class="mb-2">Teridentifikasi</p>
                                </div>
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($risiko_termitigasi); ?></h3>
                                    <p class="mb-2">Termitigasi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Penyebab</h4>
                            <div class="row">
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($penyebab_teridentifikasi); ?></h3>
                                    <p class="mb-2">Teridentifikasi</p>
                                </div>
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($penyebab_termitigasi); ?></h3>
                                    <p class="mb-2">Termitigasi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Rencana Tindak Pengendalian</h4>
                            <div class="row">
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($pengendalian_risiko); ?></h3>
                                    <p class="mb-2">Terjadwal</p>
                                </div>
                                <div class="col-md-6 text-center">
                                    <h3><?php echo e($pengendalian_risiko_termitigasi); ?></h3>
                                    <p class="mb-2">Terealisasi</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-5">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Peristiwa Risiko</h4>
                            <div class="row">
                                <div class="col-md-4 text-center">
                                    <h3><?php echo e($kejadian_peristiwa_risiko); ?></h3>
                                    <p class="mb-2">Kejadian</p>
                                </div>
                                <div class="col-md-4 text-center">
                                    <h3><?php echo e(count($risiko_peristiwa_risiko)); ?></h3>
                                    <p class="mb-2">Risiko</p>
                                </div>
                                <div class="col-md-4 text-center">
                                    <h3><?php echo e(count($penyebab_peristiwa_risiko)); ?></h3>
                                    <p class="mb-2">Penyebab</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
$(function() {
    flatpickr("#tanggal", {
        enableTime: false,
        dateFormat: "d-m-Y",
        mode: "range"
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\UKK\ARMS2\resources\views/backend/dashboard/index.blade.php ENDPATH**/ ?>